from ada_const import *

"""
two possible values, CLUSTER or LOCAL
"""
current_context = CLUSTER
